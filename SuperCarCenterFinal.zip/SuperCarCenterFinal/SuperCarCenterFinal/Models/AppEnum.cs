﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperCarCenter
{
    public class AppEnum
    {
        public enum ManagerAction
        {
            None,
            ListCarInventory,
            DisplayCarInfo,
            DeleteCarInfo,
            AddCarInfo,
            UpdateCarInfo,
            QuerySuperCarsByPrice,
            QuerySuperCarsByHp,
            Quit
        }
    }
}
