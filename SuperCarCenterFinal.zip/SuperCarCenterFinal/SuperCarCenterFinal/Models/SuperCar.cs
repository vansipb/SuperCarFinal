﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperCarCenter
{
    public class CarInfo
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public int Horse { get; set; }
        public string Color { get; set; }

        public CarInfo()
        {

        }

        public CarInfo(int id, string Name, int price, int horse, string color)
        {
            this.ID = id;
            this.Name = Name;
            this.Price = price;
            this.Horse = horse;
            this.Color = color;
        }
    }
}
