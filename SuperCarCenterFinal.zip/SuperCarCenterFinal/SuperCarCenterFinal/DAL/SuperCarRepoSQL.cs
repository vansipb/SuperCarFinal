﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Configuration;


namespace SuperCarCenter
{
    public class SuperCarRepoSQL : ISuperCarRepository
    {
        private IEnumerable<CarInfo> _SuperCar = new List<CarInfo>();
        #region Methods
        public SuperCarRepoSQL()
        {
            _SuperCar = ReadAllSuperCars();
        }

        private IEnumerable<CarInfo> ReadAllSuperCars()
        {
            IList<CarInfo> superCars = new List<CarInfo>();

            string connString = GetConnectionString();
            string sqlCommandString = "SELECT * from SuperCar";

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlCommand sqlCommand = new SqlCommand(sqlCommandString, sqlConn))
            {
                try
                {
                    sqlConn.Open();
                    using (SqlDataReader reader = sqlCommand.ExecuteReader())
                    {
                        if (reader != null)
                        {
                            while (reader.Read())
                            {
                                CarInfo superCar = new CarInfo();
                                superCar.ID = Convert.ToInt32(reader["ID"]);
                                superCar.Name = reader["Name"].ToString();
                                superCar.Price = Convert.ToInt32(reader["Price"]);
                                superCar.Horse = Convert.ToInt32(reader["HorsePower"]);
                                superCar.Color = reader["Color"].ToString();
                                superCars.Add(superCar);
                            }
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }

            return superCars;
        }

        // method to return a Car given the ID
        // uses a DataSet to hold car information
        public CarInfo SelectById(int Id)
        {
            return _SuperCar.Where(sr => sr.ID == Id).FirstOrDefault();
        }

        // method to return a list of cars
        // uses a DataSet to hold car info
        public List<CarInfo> SelectAll()
        {
            return _SuperCar as List<CarInfo>;
        }

        // method to add a new car
        public void Add(CarInfo superCar)
        {
            string connString = GetConnectionString();

            // build out SQL command
            var sb = new StringBuilder("INSERT INTO SuperCar");
            sb.Append(" ([ID],[Name],[Price],[HorsePower],[Color])");
            sb.Append(" Values (");
            sb.Append("'").Append(superCar.ID).Append("',");
            sb.Append("'").Append(superCar.Name).Append("',");
            sb.Append("'").Append(superCar.Price).Append("',");
            sb.Append("'").Append(superCar.Horse).Append("',");
            sb.Append("'").Append(superCar.Color).Append("')");
            string sqlCommandString = sb.ToString();

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlDataAdapter sqlAdapter = new SqlDataAdapter())
            {
                try
                {
                    sqlConn.Open();
                    sqlAdapter.InsertCommand = new SqlCommand(sqlCommandString, sqlConn);
                    sqlAdapter.InsertCommand.ExecuteNonQuery();
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }
        }

        // method to delete a car by car ID
        public void Delete(int ID)
        {
            string connString = GetConnectionString();

            // build out SQL command
            var sb = new StringBuilder("DELETE FROM SuperCar");
            sb.Append(" WHERE ID = ").Append(ID);
            string sqlCommandString = sb.ToString();

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlDataAdapter sqlAdapter = new SqlDataAdapter())
            {
                try
                {
                    sqlConn.Open();
                    sqlAdapter.DeleteCommand = new SqlCommand(sqlCommandString, sqlConn);
                    sqlAdapter.DeleteCommand.ExecuteNonQuery();
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }
        }

        // method to update an existing car
        public void Update(CarInfo superCar)
        {
            string connString = GetConnectionString();

            // build out SQL command
            var sb = new StringBuilder("UPDATE SuperCar SET ");
            sb.Append("Name = '").Append(superCar.Name).Append("', ");
            sb.Append("Price = '").Append(superCar.Price).Append("', ");
            sb.Append("HorsePower = '").Append(superCar.Horse).Append("', ");
            sb.Append("Color = '").Append(superCar.Color).Append(" ");
            sb.Append("WHERE ");
            sb.Append("ID = ").Append(superCar.ID);
            string sqlCommandString = sb.ToString();

            using (SqlConnection sqlConn = new SqlConnection(connString))
            using (SqlDataAdapter sqlAdapter = new SqlDataAdapter())
            {
                try
                {
                    sqlConn.Open();
                    sqlAdapter.UpdateCommand = new SqlCommand(sqlCommandString, sqlConn);
                    sqlAdapter.UpdateCommand.ExecuteNonQuery();
                }
                catch (SqlException sqlEx)
                {
                    Console.WriteLine("SQL Exception: {0}", sqlEx.Message);
                    Console.WriteLine(sqlCommandString);
                }
            }
        }

        // method to query the data by the Price of each car in feet
        public IEnumerable<CarInfo> QueryByPrice(int minimumPrice, int maximumPrice)
        {
            return _SuperCar.Where(sr => sr.Price >= minimumPrice && sr.Price <= maximumPrice);
        }

        // method to query the data by the HorsePower of each car in feet
        public IEnumerable<CarInfo> QueryByHorsePower(int minimumHorsePower, int maximumHorsePower)
        {
            return _SuperCar.Where(sr => sr.Horse >= minimumHorsePower && sr.Horse <= maximumHorsePower);
        }

        // get the connection string by name
        private static string GetConnectionString()
        {
            // Assume failure.
            string returnValue = null;

            // Look for the name in the connectionStrings section.
            var settings = ConfigurationManager.ConnectionStrings["SuperCarCenter_Local"];

            // If found, return the connection string.
            if (settings != null)
                returnValue = settings.ConnectionString;

            return returnValue;
        }

        // method to handle the IDisposable interface contract
        public void Dispose()
        {
            _SuperCar = null;
        }
    }
}
#endregion